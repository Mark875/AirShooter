﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Air_shooter.Classes;
using Air_shooter.Classes.UI;

namespace Air_shooter
{
    public enum GameState { Menu, Game, Info, Exit, GameOver }
    public enum GameDifficulty { VeryEasy, Easy, Medium, Hard, VeryHard, Impossible }
    public class Game1 : Game
    {
        private Random random = new Random();

        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;

        public static GameState gameState;
        private static GameDifficulty gameDifficulty;

        private Player player;
        private List<Mine> mines;
        private List<Explosion> explosions;
        private List<Enemy> enemies;
        private List<Laser> lasers_of_dead_enemies;
        private Space air;
        private Menu menu;
        private HUD hud;
        private GameOver gameOver;
        private Info info;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            gameState = GameState.Menu;
            gameDifficulty = GameDifficulty.VeryEasy;
            player = new Player();
            air = new Space();
            menu = new Menu();
            menu.SetMenuPosition(new Vector2(370, 180));
            mines = new List<Mine>();
            explosions = new List<Explosion>();
            enemies = new List<Enemy>();
            lasers_of_dead_enemies = new List<Laser>();
            hud = new HUD();
            gameOver = new GameOver();
            info = new Info();

            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            player.LoadContent(Content);
            air.LoadContent(Content);
            menu.LoadContent(Content);
            hud.LoadContent(Content);
            gameOver.LoadContent(Content);
            info.LoadContent(Content);
        }

        protected override void Update(GameTime gameTime)
        {
            //if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                //Exit();

            // TODO: Add your update logic here

            switch (gameState)
            {
                case GameState.Menu:
                    air.Update();
                    menu.Update();
                    break;
                case GameState.Game:
                    UpdateGame(gameTime);
                    if (Keyboard.GetState().IsKeyDown(Keys.Escape)) gameState = GameState.Menu;
                    break;
                case GameState.Exit:
                    Exit();
                    break;
                case GameState.GameOver:
                    gameOver.Update();
                    if (gameOver.Leave) ResetGame();
                    break;
                case GameState.Info:
                    air.Update();
                    info.Update();
                    break;
            }

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here
            _spriteBatch.Begin();

            switch (gameState)
            {
                case GameState.Menu:
                    air.Draw(_spriteBatch);
                    menu.Draw(_spriteBatch);
                    break;
                case GameState.Game:
                    DrawGame(_spriteBatch);
                    if (Keyboard.GetState().IsKeyDown(Keys.Escape)) gameState = GameState.Menu;
                    break;
                case GameState.GameOver:
                    air.Draw(_spriteBatch);
                    gameOver.Draw(_spriteBatch);
                    break;
                case GameState.Info:
                    air.Draw(_spriteBatch);
                    info.Draw(_spriteBatch);
                    break;
            }

            _spriteBatch.End();

            base.Draw(gameTime);
        }

        private void UpdateGame(GameTime gameTime)
        {
            if (player.Score >= 10 && gameDifficulty == GameDifficulty.VeryEasy) gameDifficulty = GameDifficulty.Easy;
            if (player.Score >= 20 && gameDifficulty == GameDifficulty.Easy) gameDifficulty = GameDifficulty.Medium;
            if (player.Score >= 50 && gameDifficulty == GameDifficulty.Medium) gameDifficulty = GameDifficulty.Hard;
            if (player.Score >= 100 && gameDifficulty == GameDifficulty.Hard) gameDifficulty = GameDifficulty.VeryHard;
            if (player.Score >= 150 && gameDifficulty == GameDifficulty.VeryHard) gameDifficulty = GameDifficulty.Impossible;

            switch (gameDifficulty)
            {
                case GameDifficulty.VeryEasy:
                    UpdateMines(3); UpdateEnemies(3); break;
                case GameDifficulty.Easy:
                    UpdateMines(5); UpdateEnemies(5); break;
                case GameDifficulty.Medium:
                    UpdateMines(8); UpdateEnemies(8); break;
                case GameDifficulty.Hard:
                    UpdateMines(10); UpdateEnemies(10); break;
                case GameDifficulty.VeryHard:
                    UpdateMines(12); UpdateEnemies(12); break;
                case GameDifficulty.Impossible:
                    UpdateMines(15); UpdateEnemies(15); break;
            }

            air.Update();
            player.Update();            
            UpdateExplosions(gameTime);            
            UpdateLeftLasers();

            foreach (Mine m in mines) m.Update();

            foreach (Mine mine in mines)
            {
                #region Коллизия пуль игрока и мин
                foreach (Laser laser in player.Weapon.Ammunition)
                {
                    if (mine.BoundingBox.Intersects(laser.BoundingBox))
                    {
                        laser.Is_visible = false;
                        mine.Is_visible = false;
                        player.Score++;
                        CreateExplosion(new Vector2(mine.BoundingBox.X, mine.BoundingBox.Y));
                    }
                }
                #endregion
                #region Коллизия игрока и мин
                if (mine.BoundingBox.Intersects(player.BoundingBox))
                {
                    mine.Is_visible = false;
                    player.Health--;
                    if (player.Health <= 0) gameState = GameState.GameOver;
                    CreateExplosion(new Vector2(mine.BoundingBox.X, mine.BoundingBox.Y));
                }
                #endregion
            }

            foreach (Enemy enemy in enemies)
            {
                #region Коллизия игрока и врагов
                if (enemy.BoundingBox.Intersects(player.BoundingBox))
                {
                    enemy.Is_visible = false;
                    player.Health -= 2;
                    if (player.Health <= 0) gameState = GameState.GameOver;
                    CreateExplosion(new Vector2(enemy.BoundingBox.X, enemy.BoundingBox.Y));
                }
                #endregion
                #region Коллизия пуль игрока и врагов
                foreach (Laser laser in player.Weapon.Ammunition)
                {
                    if (enemy.BoundingBox.Intersects(laser.BoundingBox))
                    {
                        player.Score += 2;
                        enemy.Is_visible = false;
                        laser.Is_visible = false;
                        CreateExplosion(new Vector2(enemy.BoundingBox.X, enemy.BoundingBox.Y));
                    }
                }
                #endregion
                #region Коллизия пуль врагов и игрока
                foreach (Laser laser in enemy.Weapon.Ammunition)
                {
                    if (laser.BoundingBox.Intersects(player.BoundingBox))
                    {
                        laser.Is_visible = false;
                        player.Health--;
                        if (player.Health <= 0) gameState = GameState.GameOver;
                        CreateExplosion(new Vector2(laser.BoundingBox.X, laser.BoundingBox.Y));
                    }
                }
                #endregion
            }

            foreach (Laser laser in lasers_of_dead_enemies)
            {
                #region Коллизия пуль мертвых врагов и игрока
                if (laser.BoundingBox.Intersects(player.BoundingBox))
                {
                    laser.Is_visible = false;
                    player.Health--;
                    if (player.Health == 0) gameState = GameState.GameOver;
                    CreateExplosion(new Vector2(laser.BoundingBox.X, laser.BoundingBox.Y));
                }
                #endregion
            }

            hud.Update(player.Score, player.Health);
        }

        private void DrawGame(SpriteBatch brush)
        {
            air.Draw(_spriteBatch);
            player.Draw(_spriteBatch);
            foreach (Mine m in mines) m.Draw(_spriteBatch);
            foreach (Enemy e in enemies) e.Draw(_spriteBatch);
            foreach (Explosion e in explosions) e.Draw(_spriteBatch);
            foreach (Laser l in lasers_of_dead_enemies) l.Draw(_spriteBatch);
            hud.Draw(_spriteBatch);
        }

        private void UpdateMines(int max_mines)
        {
            for (int i = 0; i < mines.Count; i++)
            {
                if (!mines[i].Is_visible)
                {
                    mines.RemoveAt(i);
                    i--;
                }
            }

            for (int i = 0; i < max_mines - mines.Count; i++)
            {
                Mine m = new Mine(random.Next(800, 1200), random.Next(0, 440), random.Next(2, 4));
                mines.Add(m);
                m.LoadContent(Content);
            }
        }

        private void UpdateExplosions(GameTime gameTime)
        {
            for (int i = 0; i < explosions.Count; i++)
            {
                explosions[i].Update(gameTime);
                if (!explosions[i].Is_visible)
                {
                    explosions.RemoveAt(i);
                    i--;
                }
            }
        }

        private void UpdateEnemies(int max_enemies)
        {
            for (int i = 0; i < enemies.Count; i++)
            {
                if (!enemies[i].Is_visible)
                {
                    lasers_of_dead_enemies.AddRange(enemies[i].Weapon.Ammunition);
                    enemies.RemoveAt(i);
                    i--;
                }
            }

            for (int i = 0; i < max_enemies - enemies.Count; i++)
            {
                Enemy enemy = new EnemyPlane(new Vector2(random.Next(800, 1300), random.Next(0, 440)));
                enemy.LoadContent(Content);
                enemies.Add(enemy);
            }

            foreach (Enemy enemy in enemies) enemy.Update();
        }

        private void ResetGame()
        {
            mines.Clear();
            enemies.Clear();
            player.Weapon.Ammunition.Clear();
            explosions.Clear();
            lasers_of_dead_enemies.Clear();
            gameDifficulty = GameDifficulty.VeryEasy;
            player = new Player();
            player.LoadContent(Content);
        }

        private void CreateExplosion(Vector2 position)
        {
            position -= new Vector2(80, 55);
            Explosion e = new Explosion(position);
            e.LoadContent(Content);
            explosions.Add(e);
        }

        private void UpdateLeftLasers()
        {
            for (int i = 0; i < lasers_of_dead_enemies.Count; i++)
            {
                if (!lasers_of_dead_enemies[i].Is_visible)
                {
                    lasers_of_dead_enemies.RemoveAt(i);
                    i--;
                }
            }

            foreach (Laser laser in lasers_of_dead_enemies) laser.Update();
        }
    }
}
