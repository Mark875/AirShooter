﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace Air_shooter.Classes.UI
{
    class Info
    {
        private Label label;

        public Info()
        {
            label = new Label("This is an unfinished game and there are some problems,\n but anyway it's a game and you can't win it. You should \ndestroy as many ships and mines as you can before dying.\n Press SPACE to shoot and WASD to move. Good luck!", new Vector2(10, 100), Color.White);
        }

        public void LoadContent(ContentManager manager)
        {
            label.LoadContent(manager);
        }

        public void Draw(SpriteBatch brush)
        {
            label.Draw(brush);
        }

        public void Update() { if (Keyboard.GetState().IsKeyDown(Keys.Escape) || Keyboard.GetState().IsKeyDown(Keys.Space)) Game1.gameState = GameState.Menu; }
    }
}
