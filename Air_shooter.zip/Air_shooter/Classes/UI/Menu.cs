﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace Air_shooter.Classes.UI
{
    class Menu
    {
        private List<Label> labels;
        private string[] texts = { "Play", "Info", "Exit" };
        private int selected;
        private KeyboardState keyboard;
        private KeyboardState prevKeyboard;

        public Vector2 Position { get; set; }

        public Menu()
        {
            selected = 0;
            labels = new List<Label>();

            Vector2 position = this.Position;
            foreach (string txt in texts)
            {
                labels.Add(new Label(txt, position, Color.Yellow));
                position.Y += 30;
            }
        }

        public void SetMenuPosition(Vector2 Position)
        {
            foreach (Label lbl in labels)
            {
                lbl.Position = Position;
                Position.Y += 30;
            }
        }

        public void LoadContent(ContentManager manager)
        {
            foreach (Label lbl in labels) lbl.LoadContent(manager);
        }

        public void Update()
        {
            keyboard = Keyboard.GetState();

            if (keyboard.IsKeyDown(Keys.S) && keyboard != prevKeyboard)
            {
                if (selected < labels.Count - 1)
                {
                    labels[selected].ResetColor();
                    selected++;
                }
            }
            if (keyboard.IsKeyDown(Keys.W) && keyboard != prevKeyboard)
            {
                if (selected > 0)
                {
                    labels[selected].ResetColor();
                    selected--;
                }
            }
            if (keyboard.IsKeyDown(Keys.Enter))
            {
                switch (selected)
                {
                    case 0:
                        Game1.gameState = GameState.Game;
                        break;
                    case 1:
                        Game1.gameState = GameState.Info;
                        break;
                    case 2:
                        Game1.gameState = GameState.Exit;
                        break;
                }
            }

            prevKeyboard = keyboard;
        }

        public void Draw(SpriteBatch brush)
        {
            labels[selected].Color = Color.White;
            foreach (Label lbl in labels) lbl.Draw(brush);
        }
    }
}
