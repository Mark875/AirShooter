﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace Air_shooter.Classes.UI
{
    class Label
    {
        private SpriteFont spriteFont;
        private Color defaultColor;

        public Vector2 Position { get; set; }
        public string Text { get; set; }
        public Color Color { get; set; }

        public Label()
        {
            this.Position = Vector2.Zero;
            this.Text = "Label";
            this.Color = Color.White;
            defaultColor = Color;
        }

        public Label(string Text, Vector2 Position, Color Color)
        {
            this.Text = Text;
            this.Position = Position;
            this.Color = Color;
            defaultColor = Color;
        }

        public void ResetColor()
        {
            Color = defaultColor;
        }

        public void LoadContent(ContentManager manager)
        {
            spriteFont = manager.Load<SpriteFont>("GameFont");
        }

        public void Draw(SpriteBatch brush)
        {
            brush.DrawString(spriteFont, Text, Position, Color);
        }
    }
}
