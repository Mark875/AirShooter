﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace Air_shooter.Classes.UI
{
    class Bar
    {
        private Vector2 position;
        private Texture2D texture;
        private Texture2D texture_line;
        private Color color;
        private int number_of_sections;
        private int height;
        private int section_width;

        public Bar(Color color, Texture2D texture, Vector2 position, int height, int number_of_sections,
            int section_width)
        {
            this.color = color;
            this.texture = texture;
            this.position = position;
            this.height = height;
            this.number_of_sections = number_of_sections;
            this.section_width = section_width;
        }

        public void LoadContent(ContentManager manager)
        {
            texture = manager.Load<Texture2D>("bar");
            texture_line = manager.Load<Texture2D>("line");
        }

        public void Update(int result)
        {
            number_of_sections = result;
        }

        public void Draw(SpriteBatch brush)
        {
            // Красивое рисование с разбиванием на секции
            Rectangle destinationRectangle = new Rectangle((int)position.X + 2, (int)position.Y, section_width, height);
            Rectangle destinationRectangle_line = new Rectangle((int)position.X, (int)position.Y, 2, height);

            for (int i = 0; i < number_of_sections; i++)
            {
                brush.Draw(texture_line, destinationRectangle_line, Color.White);
                brush.Draw(texture, destinationRectangle, color);      
                destinationRectangle.X += section_width + 2;
                destinationRectangle_line.X += section_width + 2;
            }
            brush.Draw(texture_line, destinationRectangle_line, Color.White);
        }
    }
}
