﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace Air_shooter.Classes.UI
{
    class HUD
    {
        private Label lblScore;
        private Label lblWordScore;
        private Label lblWordHealth;
        private bool visibility;
        private Bar healthBar;

        public HUD()
        {
            lblScore = new Label("0", new Vector2(92, 41), Color.Fuchsia);
            lblWordScore = new Label("Score:", new Vector2(5, 40), Color.White);
            lblWordHealth = new Label("Health:", new Vector2(5, 0), Color.White);
            visibility = true;
            healthBar = new Bar(Color.White, null, new Vector2(100, 10), 25, 10, 25);
        }

        public void LoadContent(ContentManager manager)
        {
            lblScore.LoadContent(manager);
            lblWordScore.LoadContent(manager);
            lblWordHealth.LoadContent(manager);
            healthBar.LoadContent(manager);
        }

        public void Update(int score, int health)
        {
            lblScore.Text = score.ToString();
            healthBar.Update(health);
        }

        public void Draw(SpriteBatch brush)
        {
            if (!visibility) return;

            lblScore.Draw(brush);
            lblWordScore.Draw(brush);
            lblWordHealth.Draw(brush);
            healthBar.Draw(brush);
        }
    }
}
