﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace Air_shooter.Classes.UI
{
    class GameOver
    {
        private Label lblText;
        private Label lblHelp;
        private bool leave;

        public bool Leave { get { return leave; } }

        public GameOver()
        {
            lblText = new Label("Game Over", new Vector2(310, 170), Color.Red);
            lblHelp = new Label("Press SPACE to continue", new Vector2(240, 230), Color.White);
        }

        public void LoadContent(ContentManager manager) 
        { 
            lblText.LoadContent(manager);
            lblHelp.LoadContent(manager);
        }

        public void Update()
        {
            if (Keyboard.GetState().IsKeyDown(Keys.Space))
            {
                Game1.gameState = GameState.Menu;
                leave = true;
            }
        }

        public void Draw(SpriteBatch brush) 
        { 
            lblText.Draw(brush);
            lblHelp.Draw(brush);
        }
    }
}
