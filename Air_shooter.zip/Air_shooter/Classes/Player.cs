﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace Air_shooter.Classes
{
    class Player
    {
        private int speed;
        private Vector2 position;
        private Texture2D texture;
        private int score;
        private int health;
        private Rectangle boundingBox;
        private Weapon weapon;
        private Rectangle destinationRectangle;

        private List<Laser> ammunition = new List<Laser>();
        
        public Rectangle BoundingBox { get { return boundingBox; } }
        public Weapon Weapon { get { return weapon; } }
        public int Score { get { return score; } set { score = value; } }
        public int Health { get { return health; } set { health = value; } }

        public Player()
        {  
            position = new Vector2(100, 100);
            weapon = new Weapon(position, 10, 10, 20, Color.White);
            speed = 5;
            texture = null;
            health = 10;
            score = 0;
            ammunition = weapon.Ammunition;     
        }

        public void LoadContent(ContentManager manager)
        {
            texture = manager.Load<Texture2D>("player1");
            weapon.LoadContent(manager);
        }

        public void Draw(SpriteBatch brush)
        {
            //brush.Draw(texture, position, Color.White);
            destinationRectangle = new Rectangle((int)position.X, (int)position.Y, texture.Width - 39, texture.Height - 24);
            boundingBox = destinationRectangle;
            brush.Draw(texture, destinationRectangle, Color.White);
            weapon.Draw(brush);
        }

        public void Update()
        {
            KeyboardState key_state = Keyboard.GetState();

            if (key_state.IsKeyDown(Keys.Space)) weapon.Shoot();
            if (key_state.IsKeyDown(Keys.W)) position.Y -= speed;
            if (key_state.IsKeyDown(Keys.S)) position.Y += speed;
            if (key_state.IsKeyDown(Keys.A)) position.X -= speed;
            if (key_state.IsKeyDown(Keys.D)) position.X += speed;

            // Стенки
            if (position.X <= 0) position.X = 0;
            if (position.Y <= 0) position.Y = 0;
            if (position.X >= 800 - texture.Width) position.X = 800 - texture.Width;
            if (position.Y >= 480 - texture.Height) position.Y = 480 - texture.Height;

            weapon.Position = new Vector2(position.X + texture.Width - 35, position.Y + 18);
            weapon.Update();
            ammunition = weapon.Ammunition;
        }
    }
}
