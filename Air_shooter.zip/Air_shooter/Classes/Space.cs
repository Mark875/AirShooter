﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace Air_shooter.Classes
{
    class Space
    {
        private Texture2D texture1;
        private Texture2D texture2;
        private Texture2D texture3;
        private int speed;
        private Vector2 position1;
        private Vector2 position2;

        public Space()
        {
            texture1 = null;
            texture2 = null;
            texture3 = null;
            speed = 3;
            position1 = new Vector2(0, 0);
            position2 = new Vector2(-800, 0);
        }

        public void LoadContent(ContentManager manager)
        {
            texture1 = manager.Load<Texture2D>("bgLayer1");
            texture2 = manager.Load<Texture2D>("bgLayer2");
            texture3 = manager.Load<Texture2D>("mainbackground");
        }

        public void Draw(SpriteBatch brush)
        {
            brush.Draw(texture1, position1, Color.White);
            brush.Draw(texture3, position1, Color.White);
            brush.Draw(texture2, position1, Color.White);

            brush.Draw(texture1, position2, Color.White);
            brush.Draw(texture3, position2, Color.White);
            brush.Draw(texture2, position2, Color.White);
        }

        public void Update()
        {
            position1.X += speed;
            position2.X += speed;
            if (position1.X >= 800)
            {
                position1.X = 0;
                position2.X = -800;
            }
        }
    }
}
