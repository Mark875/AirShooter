﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace Air_shooter.Classes
{
    class Laser
    {       
        private Texture2D texture;
        private Vector2 position;
        private int speed;
        private bool is_visible;
        private Rectangle rect;
        private Rectangle boundingBox;
        private Vector2 size;
        private Rectangle destinationRectangle;
        private Color color;

        public Rectangle BoundingBox { get { return boundingBox; } }
        public bool Is_visible { get { return is_visible; } set { is_visible = value; } }
        public int Speed { set { speed = value; } }

        public Laser(Texture2D texture, Vector2 position, Color color)
        {
            this.texture = texture;
            this.position = position;
            this.color = color;
            speed = 0;
            is_visible = true;
            size = new Vector2(10, 10);
            rect = new Rectangle((int)position.X, (int)position.Y, (int)size.X, (int)size.Y);
        }

        public void Draw(SpriteBatch brush)
        {
            if (!is_visible) return;

            destinationRectangle = new Rectangle((int)position.X, (int)position.Y, texture.Width - 24, texture.Height - 8);

            brush.Draw(texture, destinationRectangle, color);
        }

        public void Update()
        {
            position.X += speed;
            rect = new Rectangle((int)position.X, (int)position.Y, (int)size.X, (int)size.Y);
            if (position.X >= 800 || position.X <= 0) is_visible = false;
            boundingBox = new Rectangle((int)position.X, (int)position.Y, texture.Width, texture.Height);
        }
    }
}
