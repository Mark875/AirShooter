﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace Air_shooter.Classes
{
    class Weapon
    {
        protected List<Laser> ammunition;
        protected Texture2D laser_texture;
        protected int laser_speed;
        private Vector2 position;
        private int laser_damage;
        private int delay;
        private int max_delay;
        private int number_of_lasers;
        private Color laser_color;

        public Vector2 Position { get { return position; } set { position = value; } }

        public List<Laser> Ammunition { get { return ammunition; } }

        public Weapon(Vector2 position, int delay, int speed, int number_of_lasers, Color laser_color)
        {
            this.position = position;
            this.delay = delay;
            this.laser_color = laser_color;
            max_delay = delay;
            this.laser_speed = speed;
            this.number_of_lasers = number_of_lasers;
            ammunition = new List<Laser>(number_of_lasers);
        }

        public void LoadContent(ContentManager manager)
        {
            laser_texture = manager.Load<Texture2D>("laser");

            for (int i = 0; i < ammunition.Count; i++)
            {
                Laser l = new Laser(laser_texture, position, laser_color);
                l.Speed = laser_speed;
                ammunition.Add(l);
            }
        }

        public void Update() 
        { 
            foreach (Laser l in ammunition) l.Update();

            for (int i = 0; i < ammunition.Count; i++)
            {
                if (!ammunition[i].Is_visible)
                {
                    ammunition.RemoveAt(i);
                    i--;
                }
            }
        }

        public void Draw(SpriteBatch brush) { foreach (Laser l in ammunition) l.Draw(brush); }

        public void Shoot()
        {
            if (delay > 0) delay--;

            if (delay == 0)
            {
                delay = max_delay;
                if (ammunition.Count < number_of_lasers)
                {
                    Laser laser = new Laser(laser_texture, position, laser_color);
                    laser.Speed = laser_speed;
                    ammunition.Add(laser);
                }
            }
        }
    }
}
