﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;


namespace Air_shooter.Classes
{
    class Mine
    {
        private int speed;
        private Texture2D texture;
        private Vector2 position;
        private bool is_visible;
        private Rectangle boundingBox;
        private Rectangle destinationRectangle;

        public Rectangle BoundingBox { get { return boundingBox; } }
        public bool Is_visible { get { return is_visible; } set { is_visible = value; } }

        public Mine(int x, int y, int speed)
        {
            texture = null;
            position = new Vector2(x, y);
            this.speed = speed;
            is_visible = true;
        }

        public void LoadContent(ContentManager manager)
        {
            texture = manager.Load<Texture2D>("mine");
        }

        public void Update()
        {
            position.X -= speed;
            if (position.X < 0) is_visible = false;
        }

        public void Draw(SpriteBatch brush)
        {
            destinationRectangle = new Rectangle((int)position.X, (int)position.Y, texture.Width - 8, texture.Height - 10);
            boundingBox = destinationRectangle;
            brush.Draw(texture, destinationRectangle, Color.White);
        }
    }
}
