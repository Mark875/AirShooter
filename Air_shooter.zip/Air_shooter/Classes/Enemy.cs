﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace Air_shooter.Classes
{
    class Enemy
    {
        protected Vector2 position;
        protected int speed;
        protected Texture2D texture;
        protected float rotation;
        private bool is_visible;
        private Rectangle boundingBox;
        private Rectangle destinationRectangle;
        private Weapon weapon;

        public bool Is_visible { get { return is_visible; } set { is_visible = value; } }
        public Weapon Weapon { get { return weapon; } }

        public Rectangle BoundingBox { get { return boundingBox; } }

        public Enemy(Vector2 position)
        {
            this.position = position;
            is_visible = true;
            speed = 5;
            texture = null;
            rotation = 0;
            weapon = new Weapon(position, 20, -6, 10, Color.Red);
        }

        public virtual void LoadContent(ContentManager manager) 
        {
            destinationRectangle = new Rectangle((int)position.X, (int)position.Y, texture.Width - 20, texture.Height - 20);
            boundingBox = destinationRectangle;
            weapon.LoadContent(manager);    
        }

        public void Draw(SpriteBatch brush)
        {
            destinationRectangle = new Rectangle((int)position.X, (int)position.Y, texture.Width - 20, texture.Height - 20);
            boundingBox = destinationRectangle;

            Vector2 origin = new Vector2(destinationRectangle.Width / 2, destinationRectangle.Height / 2);

            brush.Draw(texture, destinationRectangle, null, Color.White, 
                rotation, origin, SpriteEffects.None, 1);

            weapon.Draw(brush);
        }

        public virtual void Update()
        {
            position.X -= speed;

            if (position.X <= -texture.Width) is_visible = false;

            weapon.Position = new Vector2(position.X, position.Y + 11);
            weapon.Update();
            weapon.Shoot();
        }
    }
}
