﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace Air_shooter.Classes
{
    class EnemyPlane : Enemy
    {
        public EnemyPlane(Vector2 position) : base(position)
        {
            speed = 3;
        }

        public override void LoadContent(ContentManager manager)
        {
            texture = manager.Load<Texture2D>("enemy");
            base.LoadContent(manager);
        }

        public override void Update()
        {
            rotation = 1.57f;
            base.Update();
        }
    }
}
