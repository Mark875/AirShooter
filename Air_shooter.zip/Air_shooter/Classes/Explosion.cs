﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace Air_shooter.Classes
{
    class Explosion
    {
        private Texture2D texture;
        private Vector2 position;
        private float timer;
        private float interval;
        private Vector2 origin;
        private int current_frame;
        private int sprite_width;
        private int sprite_height;
        private Rectangle source_rect;
        private bool is_visible;

        public bool Is_visible { get { return is_visible; } }

        public Explosion(Vector2 position)
        {
            this.position = position;
            texture = null;
            timer = 0;
            interval = 20;
            current_frame = 1;
            sprite_width = 117;
            sprite_height = 117;
            is_visible = true;
            origin = Vector2.Zero;
        }

        public void LoadContent(ContentManager manager)
        {
            texture = manager.Load<Texture2D>("explosion3");
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(texture, position, source_rect, Color.White, 0, origin, 1, SpriteEffects.None, 0);
        }

        public void Update(GameTime gameTime)
        {
            float t = (float)gameTime.ElapsedGameTime.TotalMilliseconds;

            timer += t;

            if (timer >= interval)
            {
                current_frame++;
                timer = 0;
            }

            if (current_frame == 17)
            {
                current_frame = 0;
                is_visible = false;
            }

            source_rect = new Rectangle(sprite_width * current_frame, 0, sprite_width, sprite_height);
        }
    }
}
